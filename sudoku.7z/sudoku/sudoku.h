/****************************************************************************
 * sudoku.h
 *
 * CS50 AP
 * Sudoku (Part 1)
 *
 * Compile-time options for the game of Sudoku.
 ***************************************************************************/

// game's author
#define AUTHOR "André Cruz and John Harvard"

// game's title
#define TITLE "Sudoku"

// banner's colors
#define FG_BANNER COLOR_RED
#define BG_BANNER COLOR_WHITE

// grid's colors
#define FG_GRID COLOR_WHITE
#define BG_GRID COLOR_BLACK

// border's colors
#define FG_BORDER COLOR_WHITE
#define BG_BORDER COLOR_BLUE

// logo's colors
#define FG_LOGO COLOR_YELLOW
#define BG_LOGO COLOR_BLACK

// digits's colors
#define FG_DIGITS COLOR_BLACK
#define BG_DIGITS COLOR_WHITE

// Colors for won game
#define FG_WON COLOR_GREEN
#define BG_WON COLOR_WHITE

// Colors for initial numbers
#define FG_INIT COLOR_YELLOW
#define BG_INIT COLOR_BLACK

// nicknames for pairs of colors
enum { PAIR_BANNER = 1, PAIR_GRID, PAIR_BORDER, PAIR_LOGO, PAIR_DIGITS, PAIR_WON, PAIR_INIT };
